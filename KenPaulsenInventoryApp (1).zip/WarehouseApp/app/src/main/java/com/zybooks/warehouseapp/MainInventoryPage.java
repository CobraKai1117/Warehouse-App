package com.zybooks.warehouseapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainInventoryPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_inventory_page);
    }
}